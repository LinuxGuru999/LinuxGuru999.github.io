# droid-term

Bootstrap a productive terminal environment on Android

https://LinuxGuru999.github.io/shotgun-droid-term/
