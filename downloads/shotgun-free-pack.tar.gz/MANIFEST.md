# Shotgun Free Pack

A collection of free, no-signup tools and templates.

- **droid-term** — Bootstrap a productive terminal environment on Android — https://LinuxGuru999.github.io/shotgun-droid-term/
- **droid-use** — Local ADB and Shizuku shell toolkit for Android — https://LinuxGuru999.github.io/shotgun-droid-use/
- **Git Commit Prompt Pack** — 40 prompts that write clean, conventional commit messages — https://LinuxGuru999.github.io/shotgun-git-commit-prompt-pack/
- **JSON Formatter CLI** — Format and validate JSON from stdin or a file — https://LinuxGuru999.github.io/shotgun-json-formatter-cli/
