# JSON Formatter CLI

Format and validate JSON from stdin or a file

https://LinuxGuru999.github.io/shotgun-json-formatter-cli/
