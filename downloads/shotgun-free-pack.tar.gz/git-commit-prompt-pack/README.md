# Git Commit Prompt Pack

40 prompts that write clean, conventional commit messages

https://LinuxGuru999.github.io/shotgun-git-commit-prompt-pack/
