# droid-use

Local ADB and Shizuku shell toolkit for Android

https://LinuxGuru999.github.io/shotgun-droid-use/
